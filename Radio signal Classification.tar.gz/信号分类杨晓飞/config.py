# coding:utf8
import warnings
import torch as t
import numpy as np
from torch import nn 

class DefaultConfig(object):
    env = 'default'  # visdom 环境
    vis_port =8097 # visdom 端口
    model = 'Convnet'  # 使用的模型，名字必须与models/__init__.py中的名字一致

    #train_data_root = './data/train/'  # 训练集存放路径
    #test_data_root = './data/test1'  # 测试集存放路径
    load_model_path = '/home/kerwins/桌面/信号分类修改/checkpoints/Convnet_1205_18:41:32.pth'  # 加载预训练的模型的路径，为None代表不加载
    #load_model_path  = None
    save_confusion_matrix_path = '/results/'
    batch_size = 256  # batch size
    use_gpu = True  # user GPU or not
    num_workers = 4  # how many workers for loading data
    print_freq = 10  # print info every N batch
    label_file = 'label.csv'
    extractor_file = 'extractor.csv'
    debug_file = '/tmp/debug'  # if os.path.exists(debug_file): enter ipdb

    max_epoch = 100
    lr = 0.001  # initial learning rate
    lr_decay = 0.5  # when val_loss increase, lr = lr*lr_decay
    weight_decay = 0e-5  # 损失函数


    def _parse(self, kwargs):
        """
        根据字典kwargs 更新 config参数
        """
        for k, v in kwargs.items():
            if not hasattr(self, k):
                warnings.warn("Warning: opt has not attribut %s" % k)
            setattr(self, k, v)
        
        #opt.device =t.device('cuda') if opt.use_gpu else t.device('cpu')


        print('user config:')
        for k, v in self.__class__.__dict__.items():
            if not k.startswith('_'):#如果不是用下划线开头的变量全部打印出来
                print(k, getattr(self, k))

opt = DefaultConfig()
'''
def weights_normal_init(model):
        
        if isinstance(model,list):
            for m in model :
                weights_normal_init(m)

        else: 
            for m in model.modules():

                if isinstance(m,nn.Conv2d):
                    t.nn.init.xavier_uniform(m.weight.data) #xavier初始化方法
                    #t.nn.init.xavier_uniform(m.bias.data)
                    m.bias.data.fill_(0.0)

                elif isinstance(m,nn.Linear):

                    t.nn.init.normal(m.weight.data)  #he_normal  正态分布初始化方法
                    #t.nn.init.normal(m.bias.data)
'''                 