from __future__ import division 
import numpy as np 
import matplotlib.pyplot as plt 
from matplotlib.ticker import MultipleLocator
from config import opt 


def plotCM(classes,matrix,savname):

	""" classes : a list of class names"""

	matrix  = matrix.astype(np.float)
	linesum = matrix.sum(1)
	linesum = np.dot(linesum.reshape(-1,1),np.ones((1,matrix.shape[1])))
	matrix /= linesum 

	#plot 
	plt.switch_backend('agg') #???
	fig = plt.figure()
	ax = fig.add_subplot(111)
	cax = ax.matshow(matrix)
	fig.colorbar(cax)#???
	ax.xaxis.set_major_locator(MultipleLocator(1))
	ax.yaxis.set_major_locator(MultipleLocator(1)) #???

	for i in range(matrix.shape[0]):
		ax.text(i,i,str('%.2f' %(matrix[i,i]*100)),va='center',ha='center')
	ax.set_xticklabels([''] +classes,rotation=90)
	ax.set_yticklabels([''] +classes)

	#save
	plt.savefig(savname)

if __name__ =='__main__':

	matrix = np.array([[1,1,0],[2,1,0],[1,2,1]])
	labels = ["snaker","toys","ship"]
	plotCM(labels,matrix,"test")