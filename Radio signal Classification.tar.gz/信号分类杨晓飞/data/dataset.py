# coding:utf8
import os
import pickle 
import torch as t
from torch.utils import data
import numpy as np
from tqdm import tqdm 
from torch.utils.data import DataLoader
from torchvision import transforms as T
import matplotlib.pyplot as plt 
import ipdb



def to_onehot(yy):
    yy1 = np.zeros([len(yy), max(yy)+1])
    yy1[np.arange(len(yy)),yy] = 1
    return yy1


class Modulation_Signal(data.Dataset):

    def __init__(self,train):
        """
        主要目标： 获取所有图片的地址，并根据训练，验证，测试划分数据
        """
        #self.test = test
        #imgs = [os.path.join(root, img) for img in os.listdir(root)]

        # test1: data/test1/8973.jpg
        # train: data/train/cat.10004.jpg 
        with open("/home/kerwins/桌面/RML2016.10a_dict.pkl",'rb') as xd1:
            Xd = pickle.load(xd1,encoding='latin1')
        snrs,mods = map(lambda j : sorted(list(set(map(lambda x: x[j],Xd.keys())))),[1,0]) #extract all the snrs and labels in database 


        X = [] 
        lbl = [] 
        for mod in mods :
            for snr in snrs :
                X.append(1000*Xd[(mod,snr)])  #sorted align mod,snr like this : qpsk,-20db,qpsk,-18db ......
                for i in range(Xd[(mod,snr)].shape[0]): lbl.append((mod,snr))
        X = np.vstack(X)
        
        np.random.seed(2016)
        n_examples = X.shape[0]
        n_train = n_examples *0.5 
        train_idx = np.random.choice(range(0,n_examples),size=int(n_train),replace=False)
        test_idx  = list(set(range(0,n_examples))-set(train_idx))

        trainy  = list(map(lambda x: mods.index(lbl[x][0]),train_idx))
        label_tn   = to_onehot(trainy)

        label_tt   = to_onehot(list(map(lambda x: mods.index(lbl[x][0]),test_idx)))
        snr_t        = list(map(lambda x: lbl[x][1],test_idx))
        #tiaozhifangshiyekeyizheyangfangxieyige!

        self.train =  train 
        self.X_train = X[train_idx]
        self.X_test  = X[test_idx]
        self.label_tt = label_tt 
        self.label_tn = label_tn
        self.classes  = mods
        self.snrs      = snr_t  




    def __getitem__(self, index):
        """
        一次返回一张图片的数据
        """
        #img_path = self.imgs[index]
        if self.train:
            data    = self.X_train[index]
            label   = self.label_tn[index]
            #label = int(self.imgs[index].split('.')[-2].split('/')[-1])
        else:
            #label = 1 if 'dog' in img_path.split('/')[-1] else 0
            data    = self.X_test[index]
            label   = self.label_tt[index]#,self.snr[index]

        return data,label 

    def __len__(self):
        if self.train:
            return len(self.X_train)
        else :
            return len(self.X_test)




if __name__ =='__main__':

    train_data = Modulation_Signal(train=True)
    train_dataloader = DataLoader(train_data,256,
                        shuffle=False,num_workers=4)

    for ii,(data,label) in tqdm(enumerate(train_dataloader)):

        print(data)
        print(label)

        if ii % 5 == 0:
            break
