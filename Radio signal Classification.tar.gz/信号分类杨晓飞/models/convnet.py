
# coding:utf8
from torch import nn
import  torch.nn.functional as F
import time
import torch as t   
from torch.optim import Adam


class Convnet(nn.Module):


	def __init__(self,number_class=11):
		super(Convnet,self).__init__()
		self.number_class = number_class
		self.model_name   = "Convnet"
		self.main = nn.Sequential(
			nn.Conv2d(1,256,kernel_size=(1,3),padding=(0,2),stride=(1,1)), #padding=(0,2)的话是在列上补齐0,等于(2,0)是上下的在行上补齐0
			#nn.BatchNorm2d(256),
			nn.ReLU(),#inplace为True，将会改变输入的数据，否则不会改变原输入，只会产生新的输出
			nn.Dropout(0.5),
			nn.Conv2d(256,80,kernel_size=(2,3),padding=(0,2),stride=(1,1)),
			#nn.BatchNorm2d(80),
			nn.ReLU(),
			nn.Dropout(0.5),
			)

		self.classifier = nn.Sequential(

			
			nn.Linear(10560,256),
			#nn.BatchNorm2d(256),
			nn.ReLU(),
			nn.Dropout(0.5),
			nn.Linear(256,number_class),
			)
			#reshape(len(class))

	def forward(self,x):
		x = self.main(x) #-----
		x = x.view(x.size(0),10560)
		x = self.classifier(x)
		#x = F.log_softmax(x)
		return x 

	def save(self, name=None):
		"""
		保存模型，默认使用“模型名字+时间”作为文件名
		"""
		if name is None:
			prefix = 'checkpoints/' + self.model_name + '_'
			name = time.strftime(prefix + '%m%d_%H:%M:%S.pth')
		t.save(self.state_dict(), name)
		return name

	def load(self, path):
		"""
		可加载指定路径的模型
		"""
		self.load_state_dict(t.load(path))

	



	