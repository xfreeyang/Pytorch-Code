#coding:utf8
import config
from config import opt
import os
import torch as t
import numpy as np
import models
import ipdb 
import torch.nn.functional as F
from torch.autograd import Variable as V
from data.dataset import Modulation_Signal
from torch.utils.data import DataLoader
from torchnet import meter
from utils.visualize import Visualizer
from utils.confusion_matrix import plotCM
from tqdm import tqdm
import ipdb
'''
def write_before_result(results,file_name):
    import csv 
    with open(file_name,'w') as f :
        writer = csv.writer(f)
        writer.writerows(results)
'''
#@t.no_grad() # pytorch>=0.5
def test(**kwargs):
    opt._parse(kwargs)

    # configure model
    model = getattr(models, opt.model)().eval()
    if opt.load_model_path:
        model.load(opt.load_model_path)
    #model.to(opt.device)
    model.cuda() if opt.use_gpu == True else model
    # data
    test_cm = meter.ConfusionMeter(11)
    data = Modulation_Signal(train=False)
    
    classes = data.classes #270
    test_data = data.X_test#482
    test_label= data.label_tt#488
    SNRS = data.snrs
    snrs = set(SNRS) 


    
    for snr in snrs :

        test_X_i = test_data[np.where(np.array(SNRS)==snr)]
        test_Y_i = test_label[np.where(np.array(SNRS)==snr)]

        test_Y_i = t.LongTensor(test_Y_i)
        _,target = t.max(test_Y_i,dim=1)
        
        test_dataloader = DataLoader(test_X_i,batch_size=opt.batch_size,shuffle=False,num_workers=opt.num_workers,drop_last=True)
        
        
        for ii,data in tqdm(enumerate(test_dataloader)):
            
            data  = V(data.unsqueeze(1))
            data =  data.cuda() if opt.use_gpu==True else data 
            test_pred = model(data)# 955m
            prob  = F.softmax(test_pred,dim=1)

            batch_target = target[ii*opt.batch_size:(ii+1)*opt.batch_size] 
            #print(prob)
            #print(batch_target)
            test_cm.add(prob.data,batch_target)
            #_,pred = t.max(prob,dim=1)
            
        plotCM(classes=classes,matrix=test_cm.value(),savname=str(snr))
        #ipdb.set_trace()
        
        '''
        
        t_results = t.stack(results).transpose(0,1)
        print(t_results.data.size()) 
        
        target = target[:t_results.shape[0]*t_results.shape[1]]
        t_target = V(t.Tensor(target).view(-1,256).transpose(0,1))
        print(t_target.data.size())
        ipdb.set_trace()
        
        test_cm.add(t_results.data,t_target.data)

        plotCM(classes=classes,matrix=test_cm.value(),savname=str(snr))
        '''

    #test_dataloader = DataLoader(test_data,batch_size=opt.batch_size,shuffle=False,num_workers=opt.num_workers)



    
def train(**kwargs):
    opt._parse(kwargs)
    vis = Visualizer(opt.env,port = opt.vis_port) 

    # step1: configure model
    model = getattr(models, opt.model)().train()

    #config.weights_normal_init(model)
    if opt.load_model_path:
        model.load(opt.load_model_path)

    print(model.model_name)

    #model.to(opt.device)#根据use_gpu选择将模型转移到gpu上还是cpu上
    model.cuda() if opt.use_gpu == True else model()

    # step2: data
    train_data = Modulation_Signal(train=True)
    test_data  = Modulation_Signal(train=False)
    #val_data = DogCat(opt.train_data_root,train=False)
    train_dataloader = DataLoader(train_data,opt.batch_size,
                        shuffle=True,num_workers=opt.num_workers)
    test_dataloader = DataLoader(test_data,opt.batch_size,
                        shuffle=False,num_workers=opt.num_workers)
    
    # step3: criterion and optimizer
    #criterion = t.nn.CrossEntropyLoss().to(opt.device)
    criterion = t.nn.CrossEntropyLoss().cuda() if opt.use_gpu == True else t.nn.CrossEntropyLoss()
    lr = opt.lr 
    optimizer = t.optim.Adam(model.parameters(), lr=lr, weight_decay=opt.weight_decay)#model.get_optimizer(lr, opt.weight_decay)

    # step4: meters
    loss_meter = meter.AverageValueMeter()#meter可以帮助用户快速统计训练过程中的一些指标，AverageValueMeter计算所有数的平均值和标准差
    confusion_matrix = meter.ConfusionMeter(11)
    previous_loss = 1e10
    classes  = train_data.classes 
    print(classes)

    # train
    for epoch in range(opt.max_epoch):
        
        loss_meter.reset()
        confusion_matrix.reset()

        #for ii,(data,label,classes) in tqdm(enumerate(train_dataloader)):
        for ii,(data,label) in tqdm(enumerate(train_dataloader)): 
            # train model 
            #input = data.to(opt.device)
            data = V(data.unsqueeze(1)) #128*1*2*128
    
            input = data.cuda() if opt.use_gpu == True else data
            label = V(label)
            
            target = label.type(t.LongTensor).cuda() if opt.use_gpu == True else label.type(t.LongTensor)
            _,target = t.max(target,1) 
            print(target) #256*11
            ipdb.set_trace()
            optimizer.zero_grad()
            score = model(input)

            print(score)
            ipdb.set_trace()

            loss = criterion(score,target)
            #print(loss)
            #ipdb.set_trace()
            loss.backward()
            optimizer.step()
            
            params = list(model.named_parameters())
            (name,param) = params[0]  #0:main.0.weight1 ,1:main.0.bias1  conv1
            print(name)               #2:main.1.weight1, 3:main.1.bias1  conv2
            print(param.grad)         #4:classifier.0.weight, 5:classifier.0.bias  Linear1
            print('--------------------------------')#6:classifier.3.weight,7:classifier.3.bias
            #(name2,param2) = params[1]
            #print(name2)
            #print(param2.grad)
            #print('--------------------------------')
           # ipdb.set_trace()
            
            # meters update and visualize
            loss_meter.add(loss.data[0])
            # detach 一下更安全保险
            confusion_matrix.add(score.data, target.data) 
            #ipdb.set_trace()
            if (ii + 1)%opt.print_freq == 0:
                vis.plot('loss', loss_meter.value()[0])
                
                # 进入debug模式
                if os.path.exists(opt.debug_file):
                    ipdb.set_trace()


        model.save()

        # validate and visualize
        
        val_cm,val_accuracy = val(model.cuda(),test_dataloader)

        vis.plot('val_accuracy',val_accuracy)
        vis.log("epoch:{epoch},lr:{lr},loss:{loss}".format(epoch = epoch,loss = loss_meter.value()[0],lr=lr))
        val_cm_np=np.array(val_cm.value())
        plotCM(classes=classes,matrix=val_cm_np,savname="test")
        # update learning rate
        if loss_meter.value()[0] > previous_loss:          
            #lr = lr * opt.lr_decay
            # 第二种降低学习率的方法:不会有moment等信息的丢失
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr * opt.lr_decay
        

        previous_loss = loss_meter.value()[0]

#@t.no_grad()
def val(model,dataloader):
    """
    计算模型在验证集上的准确率等信息
    """
    model.eval()
    value_sum = 0
    confusion_matrix = meter.ConfusionMeter(11)
    for ii, (test_input, label) in tqdm(enumerate(dataloader)):
        #val_input = val_input.to(opt.device)
        test_input = V(test_input.unsqueeze(1))
        test_input = test_input.cuda() if opt.use_gpu == True else test_input
        score = model(test_input)
        confusion_matrix.add(score.data.squeeze(), label.type(t.LongTensor))

    model.train()
    cm_value = confusion_matrix.value()
    for i in range(11):
        value_sum += cm_value[i][i]
        value_avg  = value_sum / (cm_value.sum())
    #accuracy = 100. * (cm_value[0][0] + cm_value[1][1]) / (cm_value.sum())
    return confusion_matrix, value_avg


def help():
    """
    打印帮助的信息： python file.py help
    """
    
    print("""
    usage : python file.py <function> [--args=value]
    <function> := train | test | help
    example: 
            python {0} train --env='env0701' --lr=0.01
            python {0} test --dataset='path/to/dataset/root/'
            python {0} help
    avaiable args:""".format(__file__))

    from inspect import getsource
    source = (getsource(opt.__class__))
    print(source)

if __name__=='__main__':
    import fire
    fire.Fire()
